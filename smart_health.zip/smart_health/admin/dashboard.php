<?php
session_start();
if(!isset($_SESSION['userid'])){
    header("location:login.php");
} 
?>
<!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Smart Health Prediction System</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
 </head>

 <body>
     <!-- HEADER -->
     <?php include "../includes/header.php" ?>

     <div class="container-fluid" style="height:80vh">
         <!-- 1ST ROW -->
         <div class="row">
             <div class="col-sm-12 mt-5">
                 <h2 style="text-align:center">Admin Dashboard</h2>
             </div>
         </div>

         <!-- 2ND ROW -->
         <div class="row">
             <div class="col-sm-4">
                 <div class="card m-3 shadow">
                     <!-- <div class="card-header">
                        Birthday
                     </div>
                     <img src="img.jpg"> -->
                     <div class="card-body shadow">
                         <h3 style="text-align:center">Manage Symptoms</h3>
                         <p style="text-align:center">Add, View, Edit, Delete Symptoms</p>
                         <!-- BUTTON -->
                         <div class="col-sm-12 mt-3 d-flex justify-content-center">
                             <div class="">
                                 <a class="btn btn-primary btn-outline-info btn-block text-light" href="../admin/add_symptom.php">Add</a>
                                  <a class="btn btn-white btn-outline-primary btn-block text-blue" href="../admin/view_symptoms.php">View</a>
                             </div>

                         </div>

                     </div>
                     <!-- <div class="card-footer">
                        Price:450
                     </div> -->
                 </div>
             </div>



             <div class="col-sm-4">
                 <div class="card m-3 shadow">
                     <div class="card-body shadow">
                         <h3 style="text-align:center">Manage Diseases</h3>
                         <p style="text-align:center">Add, View, Edit, Delete Diseases</p>
                         <!-- BUTTON -->
                         <div class="col-sm-12 mt-3 d-flex justify-content-center">
                             <div class="">
                                 <a class="btn btn-success btn-outline-info btn-block text-light" href="../admin/add_disease.php">Add</a>
                                 <a class="btn btn-white btn-outline-success btn-block text-blue" href="../admin/view_diseases.php">View</a>
                                </div>
                         </div>
                     </div>
                 </div>
             </div>



             <div class="col-sm-4">
                 <div class="card m-3 shadow">
                     <div class="card-body shadow">
                         <h3 style="text-align:center">Manage Doctors</h3>
                         <p style="text-align:center">Add, View, Edit, Delete Doctors</p>
                         <!-- BUTTON -->
                         <div class="col-sm-12 mt-3 d-flex justify-content-center">
                             <div class="">
                                <a class="btn btn-warning btn-outline-warning btn-block text-dark" href="../admin/add_doctor.php">Add</a>
                                 <a class="btn btn-white btn-outline-warning btn-block text-blue" href="../admin/view_doctors.php">View</a>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <!-- 3RD ROW -->
         <div class="row">
             <div class="col-sm-4">
                 <div class="card m-3 shadow">
                     <div class="card-body shadow">
                         <h3 style="text-align:center">Diseases-Symptom Mapping</h3>
                         <p style="text-align:center">Map symptoms with diseaes</p>
                         <!-- BUTTON -->
                         <div class="col-sm-12 mt-3 d-flex justify-content-center">
                             <div class="">
                                  <a class="btn btn-info btn-outline-info btn-block text-dark" href="../admin/map_disease_symptom.php" >Map</a>
                                 <a class="btn btn-white btn-outline-info btn-block text-blue" href="../admin/view_mapping.php">View Mapping</a>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>

         <!-- 4TH ROW -->
         <div class="row">
             <!-- BUTTON -->
             <div class="col-sm-12 m-3 d-flex justify-content-center">
                 <div class="">
                     <a class="btn btn-danger btn-outline-danger btn-block text-light" href="../admin/logout.php">Logout</a>
                 </div>
             </div>
         </div>
     </div>

     <!-- FOOTER -->
     <?php include "../includes/footer.php" ?>
 </body>

 </html>