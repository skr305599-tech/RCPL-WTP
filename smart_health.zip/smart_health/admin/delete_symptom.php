<?php 
$id = $_GET['sid'];
include '../config/db.php';
$conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
$qry = "delete from symptoms where symptom_id=$id";
mysqli_query($conn,$qry);
header("location:view_symptoms.php");
?>