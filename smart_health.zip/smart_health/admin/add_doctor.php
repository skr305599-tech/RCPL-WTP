<?php
 session_start();
if(!isset($_SESSION['userid'])){
    header("Location:login.php");
    exit();
 }
 ?>
<?php
$msg = "";
if (isset($_POST['add_doctor'])) {
    $doc_name = $_POST["doctor"];
    $spec_name = $_POST["specialization"];
    $contact = $_POST["cnumber"];
    include '../config/db.php';
    $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
    $qry = "insert into doctors(name, specialization , contact) values('$doc_name' , '$spec_name' , '$contact')";
    mysqli_query($conn, $qry);
    if (mysqli_affected_rows($conn) > 0) {
        $msg = "<b class='text-success'>Doctor added successfully </b>";
    } else {
        $msg = "<b class='text-danger'>Error in adding the doctor.Try again !!! </b>";
    }
    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>

<body>
    <!-- HEADER -->
    <?php include "../includes/header.php" ?>

    <div class="container mt-5" style="min-height:550px;">
        <h3 class="text-center">Add Doctor</h3>

        <form method="post">
            <input type="text" name="doctor" class="form-control mb-3" placeholder="Doctor Name">
            <input type="text" name="specialization" class="form-control mb-3" placeholder="Specialization">
            <input type="text" name="cnumber" class="form-control mb-3" placeholder="Contact Number">
            <button type="submit" name="add_doctor" class="btn btn-success">Add Doctor</button>
            <a class="btn btn-warning" href="../admin/dashboard.php">Back to Dashboard</a>
        </form>
        <br>
        <?php echo $msg; ?>
    </div>

    <!-- FOOTER -->
    <?php include "../includes/footer.php" ?>
</body>

</html>