 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Smart Health Prediction System</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
 </head>

 <body>
     <!-- HEADER -->
     <?php include "../includes/header.php" ?>

     <div class="container mt-5">
         <h3>Disease - Symptom Mapping</h3>
         <form method="post">

             <!-- DISEASES -->
             <label><b>Diseases</b></label>
             <select name="disease" class="form-control mb-3">
                 <option>-- Select Disease --</option>
                 <?php
                    $conn = mysqli_connect("localhost", "root", "", "smart_health");
                    $qry = "select * from diseases";
                    $result = mysqli_query($conn, $qry);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value='$row[disease_id]'> $row[disease_name] </option>";
                    }
                    mysqli_close($conn);

                    ?>
             </select>

             <!-- SYMPTOMS -->
             <label><b>Symptoms</b></label>
             <?php
                $conn = mysqli_connect("localhost", "root", "", "smart_health");
                $qry = "select * from symptoms";
                $result = mysqli_query($conn, $qry);
                // echo "<table class='table'>";
                $i = 0;
                while ($row = mysqli_fetch_assoc($result)) {
                    if ($i == 0)
                    echo "<div class='row mb-2'>";
                    echo "<div class='col-sm-2'>";
                    echo "<div class='form-check'>";
                    echo "<input type='checkbox' name='symptoms[]' value = '$row[symptom_id]' class='form-check-input'";
                    echo "<label class='form-check-label'>$row[symptom_name]</label>";
                    echo "</div>";
                    echo "</div>";
                    $i++;
                    if ($i == 6) {
                        echo "</div>";
                        $i = 0;
                    }
                }
                // echo "</table>";
                mysqli_close($conn);

                ?>

             <button type="submit" class="btn btn-success m-3" name="btn_map">Map</button>
             <a class="btn btn-secondary m-3" href="../admin/dashboard.php">Back to Dashboard</a>

             <?php
                if (isset($_POST['btn_map'])) {
                    $d_id = $_POST['disease'];
                    $symptoms = $_POST['symptoms'];
                    $conn = mysqli_connect("localhost", "root", "", "smart_health");

                    foreach ($symptoms as $s_id) {
                        $qry = "insert into disease_symptom(disease_id, symptom_id) values($d_id , $s_id)";
                        mysqli_query($conn, $qry);
                    }
                    if (mysqli_affected_rows($conn) > 0) {
                        echo "<b class='text-success'> Mapping Saved !!! </b>";
                    } else {
                        echo "<b class='text-danger'> Error in Mapping !!! </b>";
                        mysqli_close($conn);
                    }
                }
                ?>
             <br>
         </form>
     </div>

     <!-- FOOTER -->
     <?php include "../includes/footer.php" ?>
 </body>

 </html>