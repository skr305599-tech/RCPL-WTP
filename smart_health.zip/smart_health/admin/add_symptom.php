<?php
 $msg = "";

include '../config/db.php';
$conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);

// FETCH DATA FOR EDIT
if (isset($_GET['sid'])) {
    $id = $_GET['sid'];
    $qry = "SELECT * FROM symptoms WHERE symptom_id = $id";
    $result = mysqli_query($conn, $qry);
    $row = mysqli_fetch_assoc($result);
}

// INSERT / UPDATE
if (isset($_POST['add_symptom'])) {
    $sname = $_POST["symptom"];

    if (isset($_GET['sid'])) {
        $id = $_GET['sid'];
        $qry = "UPDATE symptoms SET symptom_name='$sname' WHERE symptom_id=$id";
    } else {
        $qry = "INSERT INTO symptoms(symptom_name) VALUES('$sname')";
    }

    mysqli_query($conn, $qry);

    if (mysqli_affected_rows($conn) > 0) {
        $msg = "<b class='text-success'>Symptom added successfully</b>";
    } else {
        $msg = "<b class='text-danger'>Error in adding the doctor.Try again !!!</b>";
    }
}

// $msg = "";
// include '../config/db.php';
// $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);

//  if (isset($_POST['add_symptom'])) {
//     $sname = $_POST["symptom"];

//     $qry = "insert into symptoms(symptom_name) values('$sname')";
//     mysqli_query($conn, $qry);
//     if (mysqli_affected_rows($conn) > 0) {
//         $msg = "<b class='text-success'>Symptom added successfully </b>";
//     } else {
//         $msg = "<b class='text-danger'>Error in adding the symptom.Try again !!! </b>";
//     }
//     mysqli_close($conn);
// }
// if (isset($_GET['sid'])) {
//     // UPDATE
//     $id = $_GET['sid'];
//     $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
//     $qry = "select * from symptoms where symptom_id = $id";
//     $result = mysqli_query($conn, $qry);
//     $row = mysqli_fetch_array($result);

// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>

<body>
    <!-- HEADER -->
    <?php include "../includes/header.php" ?>

    <div class="container mt-5" style="min-height:550px;">
        <?php
        if (isset($_GET['sid'])) {
            echo "<h3>Edit Symptoms</h3>";
        } else {
            echo "<h3>Add Symptoms</h3>";
        }
        ?>

        <form method="post">
            <input type="text" name="symptom" class="form-control mb-3" value="<?php
                                                                                if (isset($_GET['sid'])) {
                                                                                    echo $row['symptom_name'];
                                                                                } ?>" placeholder="Symptom Name">
            <button type="submit" name="add_symptom" class="btn btn-success"><?php
                                                                                if (isset($_GET['sid'])) {
                                                                                    echo "Update symptom";
                                                                                } else {
                                                                                    echo "Add symptom";
                                                                                } ?></button>
            <a class="btn btn-warning" href="../admin/dashboard.php">Back to Dashboard</a>
        </form>
        <br>
        <?php echo $msg; ?>
    </div>

    <!-- FOOTER -->
    <?php include "../includes/footer.php" ?>
</body>

</html>