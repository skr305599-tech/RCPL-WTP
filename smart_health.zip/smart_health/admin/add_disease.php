<?php
 session_start();
if(!isset($_SESSION['userid'])){
    header("Location:login.php");
  }
 ?>
 
 <?php 
$msg = "";
if (isset($_POST['add_disease'])) {
    $dname = $_POST["disease"];
    $desc = $_POST["description"];
    include '../config/db.php';
     $conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

     $qry = "insert into diseases(disease_name,description) values('$dname' , '$desc')";
    mysqli_query($conn, $qry);
    if (mysqli_affected_rows($conn) > 0) {
        $msg = "<b class='text-success'>Disease added successfully </b>";
    } else {
        $msg = "<b class='text-danger'>Error in adding the disease.Try again !!! </b>";
    }
    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>

<body>
     <?php include "../includes/header.php" ?>

    <div class="container mt-5" style="min-height:550px;">
        <h3 class="text-center">Add Disease</h3>

        <form method="post">
            <input type="text" name="disease" class="form-control mb-3" placeholder="Disease Name" required>
            <textarea name="description" class="form-control mb-3" placeholder="Description" required></textarea>
            <button type="submit" name="add_disease" class="btn btn-success">Add disease</button>
            <a class="btn btn-warning" href="../admin/dashboard.php">Back to Dashboard</a>
        </form>
           <?php echo $msg; ?>
    </div>

     <?php include "../includes/footer.php" ?>
</body>

</html>