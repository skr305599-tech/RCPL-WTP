<?php 
$id = $_GET['did'];
include '../config/db.php';
$conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
$qry = "delete from doctors where doctor_id=$id";
mysqli_query($conn,$qry);
header("location:view_doctors.php");
?>