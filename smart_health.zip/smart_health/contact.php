 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    
</head>
<body>
    <!-- HEADER -->
    <?php include "includes/header.php" ?> 

    <div class="container-fluid">


        </div>
        
        <!-- FOOTER -->
        <?php include "includes/footer.php" ?>   
</body>
</html>