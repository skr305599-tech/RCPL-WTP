<!-- <div class="container-fluid">
    <div class="row bg-dark ">
        <div class="col-sm-12 text-center text-white">
            <p>Smart Health Prediction System </p>
         </div>
        <div class="col-sm-12 text-center text-white">
             <p>@ Reserved By Alok Kumar</p>
        </div>

    </div>
</div> -->

<footer class="bg-dark text-white text-center p-3 mt-5">
            Smart Health Prediction System<br>
            @ Reserved By Alok Kumar

</footer>