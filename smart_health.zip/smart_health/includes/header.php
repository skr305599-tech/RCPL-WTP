 <nav class="navbar navbar-expand-sm bg-primary navbar-dark">
     <div class="container-fluid">
         <a class="navbar-brand fw-bold  ps-5"> <!-- href="../index.php" -->
             Smart Health
         </a>
         <!-- BUTTON -->
         <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#b1">
             <span class="navbar-toggler-icon"></span>
         </button>

         <!-- NAVBAR -->
         <div class="collapse navbar-collapse" id="b1">
             <!-- <div class=" text-left text-light">
                <p>Smart Health</p>
            </div> -->
             <ul class="navbar-nav ms-auto "> <!-- text-end -->
                 <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                 <li class="nav-item"><a class="nav-link" href="./user/register.php">Register</a></li>
                 <li class="nav-item"><a class="nav-link" href="./user/login.php">Login</a></li>
                 <li class="nav-item"><a class="nav-link" href="">Doctors</a></li>
                 <li class="nav-item"><a class="nav-link" href="">Contact</a></li>
             </ul>
         </div>
     </div>
 </nav>