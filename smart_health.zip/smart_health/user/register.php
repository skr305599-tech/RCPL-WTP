 <?php
    $msg = "";
    //  STORE IN SERVER
    if (isset($_POST['btn_reg'])) {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $pwd = $_POST["password"];
        $gender = $_POST["gender"];
        $no = $_POST["phone"];

        // Step 1. ESTABLISH THE CONNCETION
        $conn = mysqli_connect("localhost", "root", "", "smart_health");
        // Step 2. PREPARE THE QUERY
        $qry = "insert into users(name, email, password, gender, mobile_no) values('$name','$email', '$pwd' , '$gender', $no)";
        // Step 3. EXECUTE THE QUERY
        mysqli_query($conn, $qry);

        // Step 4. PROCESS THE RESULT
        if (mysqli_affected_rows($conn) > 0) {
            $msg = "<b class='text-success'> Signup successfully </b>";
        } else {
            $msg = "<b class='text-danger'> Error in Signup.Try again !!! </b>";
        }
        // Step 5. CLOSE THE CONNECTION
        mysqli_close($conn);
    }
    ?>

 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Smart Health Prediction System</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
     <script>
        function validate(){
            let email = document.getElementById("t2").value;
            let obj = new XMLHttpRequest();
            obj.open("get" , "validateemail.php?eid="+email,true);
            obj.send();
            obj.onreadystatechange= function(){
                if(obj.readyState==4 && obj.status == 200){
                    document.getElementById("l1").innerHTML = obj.responseText;
                }
            }
        }
     </script>
 </head>

 <body>
     <!-- HEADER -->
     <?php include "../includes/header.php" ?>

     <div class="container" style="min-height:550px;">
         <div class="card mx-auto mt-3 shadow" style="max-width:400px;">
             <div class="card-body">
                 <h4 class="text-center">User Registration</h4>
                 <form method="post">
                     <input type="text" name="name" class="form-control mb-3" placeholder="Full Name" required>
                     <input type="email" id ="t2" onchange="validate()" name="email" class="form-control mb-3" placeholder="Email" required>
                     <input type="password" name="password" class="form-control mb-3" placeholder="Password">
                     <input type="password" name="cpassword" class="form-control mb-3" placeholder="Confirm password">
                     <select name="gender" class="form-control mb-3">
                         <option>Choose Gender</option>
                         <option>Male</option>
                         <option>Female</option>
                        </select>
                        <input type="number" name="phone" class="form-control mb-3" placeholder="Mobile Number" required>
                        <label id="l1"></label>
                     <button type="submit" name="btn_reg" class="btn btn-primary btn-outline-info text-light w-100">Register</button>
                 </form>

                 <!-- PRINT THE OUTPUT -->
                 <?php echo $msg; ?>

             </div>
         </div>

     </div>

     <!-- FOOTER -->
     <?php include "../includes/footer.php" ?>
 </body>

 </html>