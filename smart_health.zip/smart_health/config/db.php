<?php
const HOSTNAME ="localhost";
const USERNAME = "root";
const PASSWORD = "";
const DBNAME = "smart_health"; 
?>